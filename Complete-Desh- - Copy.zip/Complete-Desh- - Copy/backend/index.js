
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcrypt';
import mysql from 'mysql2/promise';

const app = express();

app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'logindesh',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

const hashPassword = async (password) => {
  const saltRounds = 10;
  return bcrypt.hash(password, saltRounds);
};

const comparePassword = async (password, hashedPassword) => {
  return bcrypt.compare(password, hashedPassword);
};

app.post('/signup', async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ success: false, message: 'Please provide username, email, and password' });
    }

    
    const connection = await pool.getConnection();
    const [existingUser] = await connection.execute('SELECT * FROM users WHERE username = ? OR email = ?', [username, email]);
    connection.release();

    if (existingUser.length > 0) {
      return res.status(400).json({ success: false, message: 'Username or email already exists' });
    }

    
    const hashedPassword = await hashPassword(password);

    
    const insertConnection = await pool.getConnection();
    await insertConnection.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', [username, email, hashedPassword]);
    insertConnection.release();

    console.log('User registered successfully:', username);
    res.status(201).json({ success: true, message: 'User registered successfully' });
  } catch (error) {
    console.error('Error during signup:', error);
    res.status(500).json({ success: false, message: 'Internal Server Error', error: error.message });
  }
});


app.post('/login', async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (!username && !email) {
      return res.status(400).json({ success: false, message: 'Please provide username or email' });
    }

    const columnName = username ? 'username' : 'email';
    const value = username || email;

    const connection = await pool.getConnection();
    const [rows] = await connection.execute(`SELECT * FROM users WHERE ${columnName} = ?`, [value]);
    connection.release();

    if (rows.length === 0) {
      console.error('User not found for login:', value);
      return res.status(401).json({ success: false, message: 'User not found' });
    }

    const user = rows[0];

    const passwordMatch = await comparePassword(password, user.password);

    if (!passwordMatch) {
      console.error('Invalid password for user:', user.username || user.email);
      return res.status(401).json({ success: false, message: 'Invalid password' });
    }

    console.log('Login successful for user:', user.username || user.email);
    res.status(200).json({ success: true, message: 'Login successful' });
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ success: false, message: 'Internal Server Error', error: error.message });
  }
});

const port = 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});


