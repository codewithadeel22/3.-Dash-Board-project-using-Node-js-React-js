import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, Navigate } from 'react-router-dom';
import Sidebar from './Components/Sidebar';
import Dashboard from './Components/Dashboard';
import Login from './Components/Login';
import Signup from './Components/Signup';
import Assignment from './Components/Assignment'; 
import Reports from './Components/Reports'; 
import Status from './Components/Status'; 
import Message from './Components/Message'; 
import Help from './Components/Help'; 
import './App.css';

function App() {
  const storedUser = JSON.parse(localStorage.getItem('user'));
  const [user, setUser] = useState(storedUser || null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleLogin = async ({ username, email, password }) => {
    try {
      setError(null);
      setLoading(true);

      const response = await fetch('http://localhost:3000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, email, password }),
      });

      if (response.ok) {
        const loggedInUser = await response.json();
        localStorage.setItem('user', JSON.stringify(loggedInUser));
        setUser(loggedInUser);
      } else {
        const errorMessage = await response.text();
        console.error('Login failed:', errorMessage);
        setError('Login failed. Please check your credentials and try again.');
      }
    } catch (error) {
      console.error('Error during login:', error);
      setError('Error during login. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    setUser(null);
  };

  useEffect(() => {
   
  }, []);

  return (
    <div className="App">
      <Router>
        <Routes>
          <Route
            path="/"
            element={
              user ? (
                <div className="dashboard-content">
                  <Sidebar user={user} onLogout={handleLogout} />
                </div>
              ) : (
                <div className="dashboard">
                  <div className="login-out-center">
                    <div className="login-out">
                      <Login onLogin={handleLogin} loading={loading} />
                      <Link to="/signup" className="signup-button">Sign Up</Link>
                      {error && <div className="error-message">{error}</div>}
                    </div>
                  </div>
                </div>
              )
            }
          />
          <Route path="/signup" element={<Signup />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/assignment" element={<Assignment />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/status" element={<Status />} />
          <Route path="/message" element={<Message />} />
          <Route path="/help" element={<Help />} />
         
          <Route
            path="/logout"
            element={<Navigate to="/" replace />} 
          />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
