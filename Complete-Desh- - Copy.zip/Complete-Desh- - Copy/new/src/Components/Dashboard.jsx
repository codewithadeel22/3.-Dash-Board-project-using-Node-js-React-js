import React from 'react'
import Sidebar from './Sidebar'
import Content from './Content'
import Profile from './Profile'
function Dashboard() {
  return (
    <div className='dashboard-content'>
    <Sidebar/>
    <div className='dashboard-data'>
    <Content/>
    <Profile/>
    </div>
    </div>
  )
}

export default Dashboard