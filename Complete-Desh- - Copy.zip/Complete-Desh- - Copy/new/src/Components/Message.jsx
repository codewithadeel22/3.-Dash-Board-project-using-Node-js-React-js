

import React from 'react';
import Sidebar from './Sidebar';
import '../styles/message.css'; 

const messages = [
  {
    sender: 'Adeel Ahmad',
    content: 'Hi there! How are you?',
    time: '2 hours ago',
  },
  {
    sender: 'Zeeshan',
    content: 'Meeting at 3 PM. Don\'t forget!',
    time: '5 hours ago',
  },
  {
    sender: 'Abdul Jabbar',
    content: 'Got the files you requested.',
    time: '1 day ago',
  },
  {
    sender: 'Hamza',
    content: 'Hi there! How are you?',
    time: '2 days ago',
  },
  {
    sender: 'Noman',
    content: 'Happy Birthday! 🎉',
    time: '3 days ago',
  },
  {
    sender: 'Shahid',
    content: 'Finished the presentation slides.',
    time: '1 week ago',
  },
];

function Message() {
  const getColorClass = (content) => {
   
    if (content.toLowerCase().includes('meeting')) {
      return 'meeting-color';
    } else if (content.toLowerCase().includes('birthday')) {
      return 'birthday-color';
    } else {
      return 'default-color';
    }
  };

  return (
    <div className='dashboard-content'>
      <Sidebar />
      <div className='message'>
        <h1 className='message-title'>Messages</h1>
        <div className='message-list'>
          {messages.map((message, index) => (
            <div
              className={`message-item ${getColorClass(message.content)}`}
              key={index}
              style={{ animationDelay: `${index * 0.5}s` }}
            >
              <h3 className='message-sender'>{message.sender}</h3>
              <p className='message-content'>{message.content}</p>
              <p className='message-time'>Received {message.time}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Message;