import React, { useState } from 'react';
import axios from 'axios';

const Signup = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSignup = async () => {
    try {
      setError(null);
      setSuccessMessage('');
      setLoading(true);

      if (!username || !password || !email) {
        setError('Please fill in all fields');
        return;
      }

      const response = await axios.post('http://localhost:3000/signup', {
        username,
        password,
        email,
      });

      if (response.status === 201) {
        setSuccessMessage('User registered successfully');
        // You may redirect the user or perform other actions here
      } else {
        setError(response.data.message || 'Signup failed');
      }
    } catch (error) {
      setError('Error during signup. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2>Sign Up</h2>
      {error && <div style={{ color: 'red' }}>{error}</div>}
      {successMessage && <div style={{ color: 'green' }}>{successMessage}</div>}
      <label>
        Username:
        <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
      </label>
      <label>
        Password:
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
      </label>
      <label>
        Email:
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </label>
      <button onClick={handleSignup} disabled={loading}>
        {loading ? 'Signing Up...' : 'Sign Up'}
      </button>
    </div>
  );
};

export default Signup;
