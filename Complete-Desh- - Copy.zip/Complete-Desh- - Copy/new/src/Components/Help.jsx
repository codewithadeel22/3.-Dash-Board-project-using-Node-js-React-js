

import React from 'react';
import Sidebar from './Sidebar';
import '../styles/help.css'; 

const helpItems = [
  {
    question: 'How to reset my password?',
    answer: 'You can reset your password by clicking on the "Forgot Password" link on the login page.',
  },
  {
    question: 'What browsers are supported?',
    answer: 'Our platform supports the latest versions of Chrome, Firefox, Safari, and Edge.',
  },
  {
    question: 'How do I contact customer support?',
    answer: 'You can reach our customer support by emailing support@example.com or calling our helpline at (123) 456-7890.',
  },
  
];

function Help() {
  return (
    <div className='dashboard-content'>
      <Sidebar />
      <div className='help'>
        <h1 className='help-title'>Help Center</h1>
        <div className='help-list'>
          {helpItems.map((helpItem, index) => (
            <div className='help-item' key={index}>
              <h3 className='help-question'>{helpItem.question}</h3>
              <p className='help-answer'>{helpItem.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Help;
