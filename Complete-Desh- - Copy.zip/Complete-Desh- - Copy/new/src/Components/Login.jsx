

import React, { useState } from 'react';
import '../styles/Login.css';

function Login({ onLogin, loading }) {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);

  const handleLogin = async () => {
    try {
      setError(null);

      if ((!username && !email) || !password) {
        setError('Please provide username or email and password');
        return;
      }

     
      await onLogin({ username, email, password });

      
    } catch (error) {
      console.error('Error during login:', error);
      setError('Error during login. Please try again.');
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      {error && <div className="error-message">{error}</div>}
      <label>
        Username:
        <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
      </label>
      <label>
        Email:
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </label>
      <label>
        Password:
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
      </label>
      <button onClick={handleLogin} disabled={loading}>
        {loading ? 'Logging In...' : 'Login'}
      </button>
    </div>
  );
}

export default Login;
