

import React from 'react';
import Sidebar from './Sidebar';
import "../styles/report.css"; 

const reports = [
  {
    title: 'Report 1',
    content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    date: '2024-02-28',
  },
  {
    title: 'Report 2',
    content: 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    date: '2024-03-10',
  },
  {
    title: 'Report 3',
    content: 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
    date: '2024-03-20',
  },
  {
    title: 'Report 4',
    content: 'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    date: '2024-04-05',
  },
  {
    title: 'Report 5',
    content: 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
    date: '2024-04-15',
  },
  {
    title: 'Report 6',
    content: 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
    date: '2024-05-01',
  },
];

function Report() {
  return (
    <div className='dashboard-content'>
      <Sidebar />
      <div className='report'>
        <h1 className='report-title'>Reports</h1>
        <div className='report-list'>
          {reports.map((report, index) => (
            <div className='report-item' key={index}>
              <h3 className='report-title'>{report.title}</h3>
              <p className='report-content'>{report.content}</p>
              <p className='report-date'>Date: {report.date}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Report;
