import React from 'react';

import { BiLogoHtml5, BiBuilding } from 'react-icons/bi';
import { IoPhonePortraitOutline } from 'react-icons/io5';
const courses = [
  {
    title: 'Web developing',
    icon: <BiLogoHtml5 />,
  },
  {
    title: 'App developing',
    duration: '2 hours',
    icon: <IoPhonePortraitOutline />,
  },
  {
    title: 'UX & UI',
    duration: '2 hours',
    icon: <BiBuilding />,
  },
];

function Card() {
  return (
    <div className='card-container'>
    {courses.map((item)=>(
        <div className='card'>
        <div className='card-cover'>{item.icon}</div>
        <div className='card-title'>
        <h2>{item.title}</h2>
        </div>
        </div>
    ))}
    </div>
  );
}

export default Card;
