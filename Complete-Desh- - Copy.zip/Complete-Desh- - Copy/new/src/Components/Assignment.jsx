import React from 'react';
import Sidebar from './Sidebar';
import '../styles/assignment.css';

function Assignment() {
  return (
    <div className='dashboard-content'>
      <Sidebar />
      <div className='assignment'>
        <div className='assignment-head'>
          <h1 className='assignment-title'>Assignment Details</h1>
          <div className='assignment-details'>
            <div className='assignment-info'>
              <h2 className='school-name'>Developify Studios</h2>
              <a href='http://lakesideacademy.com' target='_blank' rel='noopener noreferrer' className='school-website'>
                developify.com
              </a>
              <p className='subject-teacher'>Subject: Web Developing   Teacher: Mrs. Syed Asif</p>
              <p className='grade-dates'>For Internee   Date Assigned: Feb. 01, 2024   Due Date: May. 5, 2024</p>
            </div>
            <div className='assignment-instructions'>
              <h2 className='assignment-title'>Assignment Title:</h2>
              <p className='assignment-details'>Create A Responsive Website</p>
              <h2 className='assignment-objective'>Objective:</h2>
              <p className='assignment-details'>
                To design and develop a responsive website that adapts to various screen sizes.
              </p>
              <h2 className='assignment-instructions-title'>Instructions:</h2>
              <ul className='assignment-instructions-list'>
                <li>Understand and implement responsive design principles.</li>
                <li>Utilize media queries to adjust styles based on different screen sizes.</li>
                <li>Ensure the website is functional and visually appealing on both desktop and mobile devices.</li>
              </ul>
            </div>

            <div className='assignment-analysis'>
              <h2 className='assignment-analysis-title'>Website Analysis:</h2>
              <ul className='assignment-analysis-list'>
                <li>Examine the user experience before and after implementing responsive design.</li>
                <li>Analyze the impact of design changes on the website's performance and loading times.</li>
                <li>Identify any positive or negative user feedback on the responsive features.</li>
              </ul>
            </div>
            <h2 className='assignment-report-writing'>Content Documentation:</h2>
            <ul className='assignment-report-writing-list'>
              <li>Compile detailed documentation on the responsive design implementation.</li>
              <li>Include screenshots, code snippets, and explanations to support your analysis.</li>
              <li>Conclude with reflections on the effectiveness of the responsive design choices made.</li>
            </ul>

            <div className='assignment-format'>
              <h2 className='assignment-format-title'>Code and Documentation Format:</h2>
              <ul className='assignment-format-list'>
                <li>Ensure clean and well-commented code.</li>
                <li>Use consistent indentation and coding style throughout the project.</li>
                <li>Include a README file with clear instructions on how to run the website locally.</li>
              </ul>
            </div>
            <h2 className='assignment-submission'>Code Submission:</h2>
            <ul className='assignment-submission-list'>
              <li>Submit your web development project through the Lakeside Academy student portal.</li>
              <li>Ensure your project folder is compressed into a single ZIP file.</li>
              <li>Include your name in the ZIP file: [LastName_FirstName_WebDev_Assignment.zip]</li>
            </ul>

            <h2 className='grading-criteria'>Grading Criteria:</h2>
            <ul className='grading-criteria-list'>
              <li>Quality of web development and implementation: 40%</li>
              <li>Clarity and organization of the code: 30%</li>
              <li>Originality and creativity in design: 20%</li>
              <li>Adherence to coding standards and project guidelines: 10%</li>
            </ul>
          </div>
          <hr className='divider' />
          <h2 className='category-heading'>Assignment-Specific Criteria:</h2>
          <table className='marks-table'>
            <thead>
              <tr>
                <th>Task</th>
                <th>Marks Obtained</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Task 1</td>
                <td>---</td>
              </tr>
              <tr>
                <td>Task 2</td>
                <td>---</td>
              </tr>
              
            </tbody>
          </table>
          <hr className='divider' />
          <h2 className='category-heading'>Software Development:</h2>
          <table className='marks-table'>
            <thead>
              <tr>
                <th>Task</th>
                <th>Marks Obtained</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Task 1</td>
                <td>---</td>
              </tr>
              <tr>
                <td>Task 2</td>
                <td>---</td>
              </tr>
             
            </tbody>
          </table>
          
        </div>
      </div>
    </div>
  );
}

export default Assignment;
