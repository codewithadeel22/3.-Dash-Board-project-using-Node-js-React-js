

import React from 'react';
import Sidebar from './Sidebar';
import "../styles/status.css"; 

const statuses = [
  {
    user: 'Adeel Ahmad',
    statusText: 'Working on a new project.',
    time: '2 hours ago',
  },
  {
    user: 'Abdul Jabbar',
    statusText: 'Attending a webinar.',
    time: '5 hours ago',
  },
  {
    user: 'Zeeshan',
    statusText: 'Completed a coding challenge.',
    time: '1 day ago',
  },
  {
    user: 'Noman',
    statusText: 'Preparing for a presentation.',
    time: '2 days ago',
  },
  {
    user: 'Shahid',
    statusText: 'Exploring new technologies.',
    time: '3 days ago',
  },
  {
    user: 'Hamza',
    statusText: 'Reviewing project milestones.',
    time: '1 week ago',
  },
];

function Status() {
  return (
    <div className='dashboard-content'>
      <Sidebar />
      <div className='status'>
        <h1 className='status-title'>Status Updates</h1>
        <div className='status-list'>
          {statuses.map((status, index) => (
            <div className='status-item' key={index}>
              <h3 className='status-user'>{status.user}</h3>
              <p className='status-text'>{status.statusText}</p>
              <p className='status-time'>Posted {status.time}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Status;
