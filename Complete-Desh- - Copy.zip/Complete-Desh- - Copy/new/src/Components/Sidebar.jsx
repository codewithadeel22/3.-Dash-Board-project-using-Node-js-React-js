import React from 'react';
import Dstudio from '../assets/d-studio.png';
import { NavLink, useNavigate } from 'react-router-dom';  
import {
  BiHome,
  BiMessage,
  BiSolidReport,
  BiStats,
  BiTask,
  BiHelpCircle,
  BiLogOut
} from 'react-icons/bi';
import "../styles/sidebar.css";

function Sidebar({ user, onLogout }) {
  const navigate = useNavigate();  

  const handleLogout = () => {
    localStorage.removeItem('user');
    onLogout(); 
    navigate('/'); 
  };

  return (
    <div className='menu'>
      <div className='log'>
        <img src={Dstudio} className='dvelopyfy-studio' alt="Dstudio Logo" />
      </div>
      <div className='menu--list'>
        <NavLink to='/dashboard' className='item' activeClassName='active'>
          <BiHome />
          Dashboard
        </NavLink>

        <NavLink to='/assignment' className='item' activeClassName='active'>
          <BiTask />
          Assignment
        </NavLink>

        <NavLink to='/reports' className='item' activeClassName='active'>
          <BiSolidReport />
          Report
        </NavLink>

        <NavLink to='/status' className='item' activeClassName='active'>
          <BiStats />
          Status
        </NavLink>

        <NavLink to='/message' className='item' activeClassName='active'>
          <BiMessage />
          Message
        </NavLink>

        <NavLink to='/help' className='item' activeClassName='active'>
          <BiHelpCircle />
          Help
        </NavLink>
      </div>
      <button className="logout-button1" onClick={handleLogout}>
        <BiLogOut /> Logout
      </button>
    </div>
  );
}

export default Sidebar;
