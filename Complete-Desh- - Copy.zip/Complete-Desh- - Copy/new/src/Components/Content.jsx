import React from 'react'
import ContentHeader from './ContentHeader'
import "../styles/content.css"
import Card from './Card'
import Teachers from './Teachers'
function Content() {
  return (
    <div className='content'>
    <ContentHeader/>
    <Card/>
    <Teachers/>
    </div>
  )
}

export default Content