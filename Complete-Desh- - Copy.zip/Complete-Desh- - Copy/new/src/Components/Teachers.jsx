import React, { useState } from 'react';
import "../styles/teacherlist.css";
import Image1 from "../assets/image1.jpg";

const teachers = [
  {
    image: Image1,
    name: "Pro Asif",
    duration: '3 hours lesson',
    cost: '100'
  },
  {
    image: Image1,
    name: "Pro Asif",
    duration: '3 hours lesson',
    cost: '100'
  },
  {
    image: Image1,
    name: "Pro Asif",
    duration: '3 hours lesson',
    cost: '100'
  },
];

const languageData = {
  english: {
    title: 'Teachers',
    languageOptions: [
      { value: 'english', label: 'English' },
      { value: 'urdu', label: 'Urdu' },
      { value: 'seraiki', label: 'Seraiki' },
    ],
    
    teacherNameLabel: 'Teacher Name',
    proAsif: 'Pro Asif',
    hoursLesson: '3 hours lesson',
  },
  urdu: {
    title: 'اساتذہ',
    languageOptions: [
      { value: 'english', label: 'انگریزی' },
      { value: 'urdu', label: 'اردو' },
      { value: 'seraiki', label: 'سرائیکی' },
    ],
    
    teacherNameLabel: 'استاذہ کا نام',
    proAsif: 'پروفیسر آصف',
    hoursLesson: 'تین گھنٹے کا سبق',
  },
  seraiki: {
    title: 'استاذہ',
    languageOptions: [
      { value: 'english', label: 'انگریزی' },
      { value: 'urdu', label: 'اردو' },
      { value: 'seraiki', label: 'سرائیکی' },
    ],
   
    teacherNameLabel: 'استاذہ دا ناں',
    proAsif: 'پروفیسر آصف',
    hoursLesson: 'تین گھنٹے دا سبق',
  },
};

function Teachers() {
  const [selectedLanguage, setSelectedLanguage] = useState('english');
  const strings = languageData[selectedLanguage];

  const handleLanguageChange = (e) => {
    setSelectedLanguage(e.target.value);
  };

  return (
    <div className='teacher-list'>
      <div className='list-header'>
        <h2>{strings.title}</h2>
        <select value={selectedLanguage} onChange={handleLanguageChange}>
          {strings.languageOptions.map(option => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>
      <div className='list-container'>
        {teachers.map(teacher =>
          <div className='list' key={teacher.name}>
            <div className='teacher-detail'>
              <img src={teacher.image} alt={teacher.name}/>
              <h2>{strings.proAsif}</h2>
            </div>
            <span>{strings.hoursLesson}</span>
            <span>${teacher.cost}/hr</span>
           
            <span className='teacher-name'>{strings.teacherNameLabel}: {teacher.name}</span>
          </div>
        )}
      </div>
    </div>
  );
}

export default Teachers;
